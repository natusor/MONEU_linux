MONEU 0.2.5 node, Linux x86_64

No installation and no libraries needed. Unpack and run.

The window program MI MONEU Interface:

    ./moneu-mi

It starts the node inside by itself and with buttons it handles mining and
creating the wallet and addresses and the noise file and everything that is
needed to make transactions. Keep the lib and plugins folders next to it.

The node in the terminal:

    ./moneu-test-noise
    ./moneud -daemon

The node writes to ~/.moneu and takes a few minutes to catch up with the
network. Then set up a wallet, using the same password for the first two
commands:

    ./moneu-cli createwallet "your-password"
    ./moneu-cli makenoise "your-password"
    ./moneu-cli walletunlock "your-password"
    ./moneu-cli getnewaddress

Write down the 24 words it prints. Copy the whole wallet folder to a second
drive, with the noise file inside.

Checking the balance:

    ./moneu-cli getwalletinfo
    ./moneu-cli listaddresses
    ./moneu-cli getbalance YOUR-ADDRESS

getwalletinfo shows the balance of the whole wallet. listaddresses lists
its addresses. getbalance shows the balance of any single address, split
into what can be spent now and what is still waiting to mature.

Mining on the processor, the number is how many threads to use:

    ./moneu-cli startmining YOUR-ADDRESS 4

Mining on a graphics card:

    ./moneu-cli startmining YOUR-ADDRESS gpu

No number here: the card works with thousands of units at once. GPU mining
needs an OpenCL driver.

    ./moneu-cli getmininginfo
    ./moneu-cli stopmining
    ./moneu-cli stop

MI and moneud use the same ~/.moneu so run one of them at a time. If moneud
is already running MI connects to it instead of starting a second node.

Built from https://github.com/natusor/MONEU
Website https://moneu.cc
