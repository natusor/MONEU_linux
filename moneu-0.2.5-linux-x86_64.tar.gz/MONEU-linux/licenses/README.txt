moneu-mi uses Qt 5 under the GNU LGPL version 3 together with the libraries in lib and plugins.
They are the unchanged builds shipped by Ubuntu 22.04. Each keeps its own license, copied in this folder.
Any of them can be replaced with another build of the same library.
packages.txt lists the Ubuntu packages and versions they come from.
Source code: apt-get source <package> on Ubuntu or https://launchpad.net/ubuntu/+source and Qt 5 at https://download.qt.io/archive/qt/5.15/
