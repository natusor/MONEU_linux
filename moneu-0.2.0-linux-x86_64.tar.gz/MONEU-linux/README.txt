MONEU node, Linux x86_64

No installation and no libraries needed. Unpack and run.

    ./moneu-test-noise
    ./moneud -daemon

The node writes to ~/.moneu and takes a few minutes to catch up with the
network. Then set up a wallet, using the same password for the first two
commands:

    ./moneu-cli createwallet "your-password"
    ./moneu-cli makenoise "your-password"
    ./moneu-cli walletunlock "your-password"
    ./moneu-cli getnewaddress

Write down the 24 words it prints. Copy the whole wallet folder to a second
drive, with the noise file inside.

Mining on the processor, the number is how many threads to use:

    ./moneu-cli startmining YOUR-ADDRESS 4

Mining on a graphics card:

    ./moneu-cli startmining YOUR-ADDRESS gpu

No number here: the card works with thousands of units at once. GPU mining
needs an OpenCL driver.

    ./moneu-cli getmininginfo
    ./moneu-cli stopmining
    ./moneu-cli stop

Built from https://github.com/natusor/MONEU
Website https://moneu.cc
